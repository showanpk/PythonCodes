var t="https://api.crm.saheli.co.uk",i={production:!0,apiUrl:t,apiBase:`${t}/api`};export{i as a};
